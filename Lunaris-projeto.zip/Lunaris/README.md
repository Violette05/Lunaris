# Lunaris Alpha 0.1
Toda luz tem seu começo.

Protótipo Android Kotlin/Compose, dados locais. Sem comunidade online, pagamentos, autenticação ou moderação. Compilação ainda não validada. Identificador Android anterior mantido.
