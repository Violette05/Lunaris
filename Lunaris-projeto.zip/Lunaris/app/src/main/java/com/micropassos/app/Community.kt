package com.micropassos.app

import androidx.compose.foundation.layout.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.auth.FirebaseAuth

@Composable internal fun Community(uid:String,name:String,bio:String, home:Boolean=false, avatar:String?=null) {
 val db=remember { FirebaseFirestore.getInstance() }
 val posts=db.collection("posts")
 val blocks=db.collection("users").document(uid).collection("blocks")
 var feed by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
 var blocked by remember { mutableStateOf<Set<String>>(emptySet()) }
 var body by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("") }
 var busy by remember { mutableStateOf(false) }
 var photo by remember(uid) { mutableStateOf<String?>(null) }
 var photoBusy by remember { mutableStateOf(false) }
 val context=LocalContext.current
 val scope=rememberCoroutineScope()
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){ uri ->
  if(uri!=null){photoBusy=true;scope.launch{try{photo=withContext(Dispatchers.IO){encodeFragmentPhoto(context,uri)};status=""}catch(e:Exception){status="Não foi possível preparar a foto."}finally{photoBusy=false}}}
 }
 var ready by remember { mutableStateOf(false) }
 var feedLoaded by remember { mutableStateOf(false) }
 DisposableEffect(uid) {
  val a=posts.orderBy("createdAt",Query.Direction.DESCENDING).limit(30).addSnapshotListener { snap,err -> if(err!=null) { feedLoaded=false; status="Feed indisponível: ${err.code.name}." } else { feed=snap?.documents.orEmpty(); feedLoaded=true } }
  val b=blocks.addSnapshotListener { snap,err -> ready=err==null; if(err==null) blocked=snap?.documents.orEmpty().map{it.id}.toSet() else status="Não foi possível carregar bloqueios." }
  onDispose { a.remove(); b.remove() }
 }
 Text("Fragmentos",style=MaterialTheme.typography.headlineSmall,color=MaterialTheme.colorScheme.primary)
 if(!home) Drawer("Constelações","Pessoas, Laços e Círculos"){ SocialPanel(uid,name,bio,blocked) }
 if(!home) Text("Visível à comunidade de teste.",style=MaterialTheme.typography.labelSmall)
 Drawer("Novo Fragmento","Compartilhe um momento"){
 Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){LunarAvatar(uid,name,avatar);Spacer(Modifier.width(8.dp));Text(name)};OutlinedTextField(body,{if(it.length<=1000)body=it},placeholder={Text("Compartilhe um momento…")},modifier=Modifier.fillMaxWidth())
 FragmentPhoto(photo)
 Row { TextButton(enabled=!busy&&!photoBusy,onClick={picker.launch("image/*")}){Text(if(photo==null)"Adicionar foto" else "Trocar foto")};if(photo!=null)TextButton(enabled=!busy&&!photoBusy,onClick={photo=null}){Text("Remover foto")} }
 if(photoBusy)Text("Preparando fotografia…")
 Button(enabled=!busy && !photoBusy && (body.isNotBlank() || photo!=null) && name.isNotBlank(),onClick={busy=true;posts.add(mapOf("uid" to uid,"name" to name.take(80),"bio" to bio.take(160),"body" to body.trim(),"createdAt" to FieldValue.serverTimestamp()) + (photo?.let{mapOf("image" to it)} ?: emptyMap())).addOnCompleteListener{busy=false;if(it.isSuccessful){body="";photo=null;status="Fragmento publicado."}else status="Falha ao publicar: ${ (it.exception as? com.google.firebase.firestore.FirebaseFirestoreException)?.code?.name ?: "CONEXAO" }."}}){Text("Publicar Fragmento")}
 }
 if(status.isNotBlank()) Text(status)
 if(!feedLoaded && status.isBlank()) Text("Carregando fragmentos…")
 if(ready && feedLoaded && feed.none{it.getString("uid") !in blocked}) Text("Nenhum fragmento por aqui ainda.")
 if(ready) feed.filter{it.getString("uid") !in blocked}.forEach { post -> key(post.id) {
  val author=post.getString("uid") ?: ""
  val ref=posts.document(post.id)
  var likes by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
  var comments by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
  var open by remember { mutableStateOf(false) }
  var profile by remember { mutableStateOf(false) }
  var comment by remember { mutableStateOf("") }
  var pending by remember { mutableStateOf(false) }
  DisposableEffect(post.id) { val l=ref.collection("likes").addSnapshotListener{s,e->if(e==null)likes=s?.documents.orEmpty()};onDispose{l.remove()} }
  if(open) DisposableEffect(post.id) {val l=ref.collection("comments").orderBy("createdAt").limit(50).addSnapshotListener{s,e->if(e==null)comments=s?.documents.orEmpty()};onDispose{l.remove()}}
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),elevation=CardDefaults.cardElevation(defaultElevation=6.dp),border=BorderStroke(1.dp,Color(0xFF80669E)),colors=CardDefaults.cardColors(containerColor=Color(0xFF342546))) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
   Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){LunarAvatar(author,post.getString("name") ?: "Lunaris",if(author==uid)avatar else null);TextButton(onClick={profile=!profile}){Text(post.getString("name") ?: "Lunaris")}}
   if(profile){VisitRefuge(author,post.getString("name") ?: "Lunaris");Text(post.getString("bio") ?: "");Text("Fragmentos recentes deste perfil");feed.filter{it.getString("uid")==author}.forEach{Text(it.getString("body") ?: "")}}
   Text(post.getTimestamp("createdAt")?.toDate()?.let{java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT).format(it)} ?: "Agora",style=MaterialTheme.typography.labelSmall)
   HorizontalDivider(color=Color(0xFF69537E));if(!post.getString("body").isNullOrBlank())Text(post.getString("body") ?: "",style=MaterialTheme.typography.bodyLarge);FragmentPhoto(post.getString("image"))
   Row { TextButton(enabled=!pending,onClick={pending=true;val like=ref.collection("likes").document(uid);val task=if(likes.any{it.id==uid})like.delete() else like.set(mapOf("uid" to uid));task.addOnCompleteListener{pending=false;if(!it.isSuccessful)status="Não foi possível atualizar curtida."}}){Text("${if(likes.any{it.id==uid}) "♥" else "♡"} ${likes.size}")};TextButton(onClick={open=!open}){Text("Comentários")} }
   if(open){comments.filter{it.getString("uid") !in blocked}.forEach{c->Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){LunarAvatar(c.getString("uid") ?: "unknown",c.getString("name") ?: "Lunaris");Spacer(Modifier.width(8.dp));Text("${c.getString("name")}: ${c.getString("body")}")};if(c.getString("uid")==uid)TextButton(onClick={c.reference.delete().addOnFailureListener{status="Falha ao excluir."}}){Text("Excluir comentário")}};OutlinedTextField(comment,{if(it.length<=500)comment=it},label={Text("Comentar")});Button(enabled=comment.isNotBlank()&&!pending,onClick={pending=true;ref.collection("comments").add(mapOf("uid" to uid,"name" to name.take(80),"body" to comment.trim(),"createdAt" to FieldValue.serverTimestamp())).addOnCompleteListener{pending=false;if(it.isSuccessful)comment="" else status="Falha ao comentar."}}){Text("Enviar")}}
   Drawer("Opções do Fragmento"){ if(author==uid)TextButton(onClick={ref.delete().addOnFailureListener{status="Falha ao excluir."}}){Text("Excluir publicação")} else {TextButton(onClick={db.collection("reports").document("${post.id}_$uid").set(mapOf("uid" to uid,"postId" to post.id,"createdAt" to FieldValue.serverTimestamp())).addOnCompleteListener{status=if(it.isSuccessful)"Denúncia enviada para revisão manual." else "Falha ao denunciar."}}){Text("Denunciar")};TextButton(onClick={blocks.document(author).set(mapOf("uid" to author)).addOnFailureListener{status="Falha ao ocultar."}}){Text("Ocultar autor")}} }
  }}
 }}
 if(blocked.isNotEmpty()) TextButton(onClick={blocked.forEach{blocks.document(it).delete()}}){Text("Desfazer todos os bloqueios locais do feed")}
}
