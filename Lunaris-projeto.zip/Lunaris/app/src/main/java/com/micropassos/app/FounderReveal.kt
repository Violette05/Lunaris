package com.micropassos.app

import android.media.MediaPlayer
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FounderReveal(rewards: List<Pair<String,Int>>, close: () -> Unit) {
    val context = LocalContext.current
    var opened by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    fun sound(id: Int) { player?.release(); player = runCatching { MediaPlayer.create(context,id)?.apply { setVolume(.35f,.35f); start() } }.getOrNull() }
    fun open() { if (!opened) { opened=true; sound(R.raw.pack_rip) } }
    val fade by animateFloatAsState(if(opened) 0f else 1f, tween(350), label="envelope")
    AlertDialog(onDismissRequest=close, title={Text("Relíquias do Luar")}, text={
        Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.fillMaxWidth()) {
            if(!opened || fade > .01f) {
                Image(painterResource(R.drawable.founder_pack),"Deslize para abrir",Modifier.fillMaxWidth().height(280.dp).alpha(fade).scale(1f+(1f-fade)*.12f).pointerInput(Unit){var distance=0f;detectHorizontalDragGestures(onDragStart={distance=0f},onDragEnd={if(kotlin.math.abs(distance)>65f)open()}){change,amount->change.consume();distance+=amount}},contentScale=ContentScale.Fit)
                Text("Deslize sobre o envelope")
            } else if(index<rewards.size) {
                val reward=rewards[index]; val supreme=reward.first=="Santuário de Selene"
                key(index) {
                    var visible by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit){visible=true;if(supreme)sound(R.raw.pack_chime)}
                    val scale by animateFloatAsState(if(visible)1f else .65f,tween(300),label="sticker")
                    Text(if(supreme)"✦ CLASSE S ✦" else "Classe C",color=if(supreme)Color(0xFFFFD27A) else Color(0xFFD4B8F0),fontSize=22.sp)
                    Image(painterResource(reward.second),reward.first,Modifier.fillMaxWidth().height(220.dp).scale(scale),contentScale=ContentScale.Fit)
                    Text(reward.first);Text("${index+1} / ${rewards.size}")
                }
            } else Text("Seus seis stickers estão no inventário!")
        }
    },confirmButton={TextButton(onClick={if(!opened)open() else if(index<rewards.size)index++ else close()}){Text(if(!opened)"Abrir" else if(index<rewards.size)"Continuar" else "Concluir")}})
}
