package com.micropassos.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.DocumentSnapshot
import java.io.ByteArrayOutputStream

@Composable internal fun LunarAvatar(uid:String, name:String, localPath:String?=null) {
 var frame by remember(uid){mutableIntStateOf(0)}
 DisposableEffect(uid){val l=FirebaseFirestore.getInstance().collection("lunarAuras").document(uid).addSnapshotListener{s,e->frame=if(e==null)(s?.getLong("frame")?:0).toInt().coerceIn(0,6) else 0};onDispose{l.remove()}}
 var encoded by remember(uid){mutableStateOf<String?>(null)}
 DisposableEffect(uid){val listener=FirebaseFirestore.getInstance().collection("lunarAvatars").document(uid).addSnapshotListener{s,e->encoded=if(e==null)s?.getString("image") else null};onDispose{listener.remove()}}
 val bitmap=remember(encoded,localPath){runCatching{if(localPath!=null) BitmapFactory.decodeFile(localPath,BitmapFactory.Options().apply{inSampleSize=4}) else encoded?.takeIf{it.length<=60000}?.let{val bytes=Base64.decode(it,Base64.DEFAULT);BitmapFactory.decodeByteArray(bytes,0,bytes.size)}}.getOrNull()}
 AuraFrame(frame,48){Box(Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),contentAlignment=Alignment.Center){if(bitmap!=null)Image(bitmap.asImageBitmap(),"Foto de $name",Modifier.fillMaxSize(),contentScale=ContentScale.Crop) else Text(name.take(1).uppercase().ifBlank{"☾"},color=MaterialTheme.colorScheme.primary)}}
}
private fun encodeAvatar(path:String):String?=runCatching{
 val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(path,bounds);var sample=1;while(maxOf(bounds.outWidth,bounds.outHeight)/sample>512)sample*=2
 val source=BitmapFactory.decodeFile(path,BitmapFactory.Options().apply{inSampleSize=sample}) ?: return null
 val ratio=160f/maxOf(source.width,source.height);val scaled=Bitmap.createScaledBitmap(source,(source.width*ratio).toInt().coerceAtLeast(1),(source.height*ratio).toInt().coerceAtLeast(1),true)
 val out=ByteArrayOutputStream();scaled.compress(Bitmap.CompressFormat.JPEG,75,out);Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP).takeIf{it.length<=60000}
}.getOrNull()
@Composable internal fun AvatarSharing(uid:String,path:String?){
 var status by remember{mutableStateOf("")};val ref=remember(uid){FirebaseFirestore.getInstance().collection("lunarAvatars").document(uid)}
 Drawer("Foto na comunidade") {Text("Opcional: sua foto ficará visível às contas verificadas da comunidade.");Button(enabled=path!=null,onClick={val data=path?.let(::encodeAvatar);if(data==null)status="Foto indisponível." else ref.set(mapOf("image" to data)).addOnCompleteListener{status=if(it.isSuccessful)"Foto publicada." else "Falha: ${it.exception?.message}"}}){Text("Publicar foto atual")};TextButton(onClick={ref.delete().addOnCompleteListener{status=if(it.isSuccessful)"Foto retirada." else "Falha ao retirar foto."}}){Text("Retirar foto da comunidade")};if(status.isNotBlank())Text(status)}
}
@Composable internal fun RefugeSharing(uid:String,garden:Int,decor:Set<String>,positions:Map<String,Pair<Float,Float>>,sizes:Map<String,Float>,angles:Map<String,Float>,layers:Map<String,Float>){
 var status by remember{mutableStateOf("")};val ref=remember(uid){FirebaseFirestore.getInstance().collection("lunarRefuges").document(uid)}
 Drawer("Portais do Luar","Compartilhar meu Refúgio") {Text("Publique uma cópia do cenário atual para a comunidade ver. Visitantes não podem editar.");Button(onClick={val pieces=decor.filter{n->items.any{it.first==n}}.sortedBy{layers[it]?:0f}.map{n->val pos=positions[n]?:Pair(.5f,.75f);mapOf("name" to n,"x" to pos.first,"y" to pos.second,"size" to (sizes[n]?:1f),"angle" to (angles[n]?:0f))};ref.set(mapOf("garden" to garden,"pieces" to pieces)).addOnCompleteListener{status=if(it.isSuccessful)"Refúgio publicado." else "Falha ao publicar."}}){Text("Publicar / atualizar Refúgio")};TextButton(onClick={ref.delete().addOnCompleteListener{status=if(it.isSuccessful)"Refúgio retirado." else "Falha ao retirar."}}){Text("Fechar portal")};if(status.isNotBlank())Text(status)}
}
@Composable internal fun VisitRefuge(uid:String,name:String){
 var open by remember{mutableStateOf(false)};TextButton(onClick={open=true}){Text("Visitar Refúgio")};if(!open)return
 var data by remember(uid){mutableStateOf<DocumentSnapshot?>(null)};var status by remember(uid){mutableStateOf("Carregando…")}
 DisposableEffect(uid){val l=FirebaseFirestore.getInstance().collection("lunarRefuges").document(uid).addSnapshotListener{s,e->data=if(e==null)s else null;status=if(e!=null)"Portal indisponível." else if(s?.exists()==true)"" else "Este portal está fechado."};onDispose{l.remove()}}
 AlertDialog(onDismissRequest={open=false},title={Text("Refúgio de $name")},text={if(status.isNotBlank())Text(status) else {val g=(data?.getLong("garden")?:0L).toInt().coerceIn(0,1);val pieces=data?.get("pieces") as? List<*> ?: emptyList<Any>();BoxWithConstraints(Modifier.fillMaxWidth().height(320.dp)){Image(painterResource(gardenArt[g]),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);val tx=(maxWidth-66.dp).coerceAtLeast(1.dp);val ty=(maxHeight-66.dp).coerceAtLeast(1.dp);pieces.take(10).forEachIndexed{i,raw->val p=raw as? Map<*,*> ?: return@forEachIndexed;val item=items.firstOrNull{it.first==p["name"]}?:return@forEachIndexed;fun num(k:String,d:Float):Float { return (p[k] as? Number)?.toFloat()?.takeIf{it.isFinite()}?:d };
Image(painterResource(item.third),item.first,Modifier.zIndex(i.toFloat()).offset(tx*num("x",.5f).coerceIn(0f,1f),ty*num("y",.75f).coerceIn(0f,1f)).size(66.dp).graphicsLayer{scaleX=num("size",1f).coerceIn(.5f,2.5f);scaleY=scaleX;rotationZ=num("angle",0f)%360f},contentScale=ContentScale.Fit)}}}},confirmButton={TextButton(onClick={open=false}){Text("Voltar")}})
}
