package com.micropassos.app

import android.content.SharedPreferences
import android.media.MediaPlayer
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable internal fun LunarRadio(garden:Int, prefs:SharedPreferences){
 val context=LocalContext.current
 var track by remember(garden){mutableIntStateOf(garden % 2)}
 var playing by remember{mutableStateOf(false)}
 var volume by remember{mutableFloatStateOf(prefs.getFloat("radio_volume",.35f).coerceIn(0f,1f))}
 var error by remember{mutableStateOf(false)}
 val names=listOf("Sintonia Lunar I","Sintonia Lunar II")
 val files=listOf(R.raw.lunar_0,R.raw.lunar_1)
 val player=remember(track){runCatching{MediaPlayer.create(context,files[track])?.apply{isLooping=true}}.getOrNull()}
 DisposableEffect(player){onDispose{player?.release()}}
 LaunchedEffect(player,playing,volume){runCatching{player?.setVolume(volume,volume);if(playing){if(player==null){error=true;playing=false}else player.start()}else if(player?.isPlaying==true)player.pause()}.onFailure{error=true;playing=false}}
 DisposableEffect(context){val owner=context as? ComponentActivity;val observer=LifecycleEventObserver{_,event->if(event==Lifecycle.Event.ON_PAUSE){playing=false}};owner?.lifecycle?.addObserver(observer);onDispose{owner?.lifecycle?.removeObserver(observer)}}
 Drawer("Rádio Lunar",if(playing) names[track] else "Cozy lo-fi"){
  Text(names[track]);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){
   TextButton(onClick={track=(track+files.size-1)%files.size}){Text("Anterior")}
   Button(onClick={error=false;playing=!playing}){Text(if(playing)"Pausar" else "Tocar")}
   TextButton(onClick={track=(track+1)%files.size}){Text("Próxima")}
  }
  Text("Volume ${(volume*100).toInt()}%")
  Slider(value=volume,onValueChange={volume=it;prefs.edit().putFloat("radio_volume",it).apply()})
  if(error)Text("Não foi possível reproduzir a faixa.")
  Text("Trilhas criadas com Gemini • Lunaris",style=MaterialTheme.typography.labelSmall)
 }
}
