package com.micropassos.app

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.math.cos

@Composable
internal fun SeleneMagic(modifier: Modifier = Modifier) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var active by remember(lifecycle) { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, _ -> active = lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(active) {
        if (active) while (true) { delay(50); tick = (tick + 1) % 72000 }
    }
    Canvas(modifier) {
        val t = tick * .05f
        val gold = Color(0xFFFFD98A)
        val center = Offset(size.width * .5f, size.height * .52f)
        val radius = size.minDimension * .62f
        val pulse = .10f + .09f * (sin(t * 1.4f) + 1f) / 2f
        drawCircle(Brush.radialGradient(listOf(gold.copy(alpha = pulse), Color.Transparent), center, radius), radius, center)
        repeat(8) { i ->
            val phase = ((t * .11f + i / 8f) % 1f)
            val angle = i * 2.39996f + t * .35f
            val point = Offset(center.x + cos(angle) * size.width * .43f, size.height * (.88f - phase * .82f))
            val alpha = (.75f * sin(phase * 3.1415927f)).coerceIn(0f, 1f)
            val r = size.minDimension * .018f
            drawCircle(Brush.radialGradient(listOf(gold.copy(alpha = alpha * .6f), Color.Transparent), point, r * 4f), r * 4f, point)
            drawCircle(gold.copy(alpha = alpha), r, point)
            if (i % 3 == 0) {
                drawLine(gold.copy(alpha = alpha), point - Offset(r * 2f, 0f), point + Offset(r * 2f, 0f), strokeWidth = density)
                drawLine(gold.copy(alpha = alpha), point - Offset(0f, r * 2f), point + Offset(0f, r * 2f), strokeWidth = density)
            }
        }
    }
}
