package com.micropassos.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray

private val night=Color(0xFF111020)
private val panel=Color(0xFF241B3C)
private val lunar=Color(0xFFB39AE8)
private val gold=Color(0xFFF5D9A0)
private val gardens=listOf("Jardim Lunar","Floresta Serena","Vale das Flores")
private val gardenArt=listOf(R.drawable.lunar_scene,R.drawable.garden_forest,R.drawable.garden_flowers)
private val tasks=listOf("Beber um copo de água","Abrir a janela","Ouvir uma música","Registrar algo que comeu","Fotografar algo bonito","Lembrar de uma história engraçada","Trocar de roupa","Reservar um momento de descanso","Anotar algo que gostaria de comprar")
private val items=listOf(Triple("Casa do Luar",800,R.drawable.lunar_house),Triple("Árvore dos Sonhos",450,R.drawable.lunar_tree),Triple("Lago dos Suspiros",350,R.drawable.lunar_pond))
class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme(colorScheme=darkColorScheme(primary=lunar,background=night,surface=panel,onSurface=Color.White,onBackground=Color.White)){Lunaris(this)}}}
}
@Composable private fun Art(id:Int,height:Int=150){Image(painterResource(id),null,Modifier.fillMaxWidth().height(height.dp).clip(RoundedCornerShape(18.dp)),contentScale=ContentScale.Crop)}
@Composable private fun Tile(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().border(1.dp,lunar.copy(alpha=.30f),RoundedCornerShape(18.dp))){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)}}
@Composable private fun Lunaris(context:Context){
 val p=remember{context.getSharedPreferences("lunaris_alpha",Context.MODE_PRIVATE)}
 var name by remember{mutableStateOf(p.getString("name","")?:"")};var pronoun by remember{mutableStateOf(p.getString("pronoun","")?:"")};var birth by remember{mutableStateOf("")};var garden by remember{mutableIntStateOf(p.getInt("garden",0).coerceIn(0,2))};var registered by remember{mutableStateOf(p.getBoolean("registered",false))};var stage by remember{mutableIntStateOf(0)};var error by remember{mutableStateOf("")}
 var tab by remember{mutableIntStateOf(0)};var coins by remember{mutableIntStateOf(p.getInt("coins",300))};var xp by remember{mutableIntStateOf(p.getInt("xp",0))};val day=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date());var mood by remember{mutableStateOf(p.getString("mood_$day","")?:"")};var completed by remember{mutableStateOf(p.getStringSet("tasks_$day",emptySet())!!.toSet())};var offset by remember{mutableIntStateOf(0)};var diary by remember{mutableStateOf(p.getString("diary_$day","")?:"")};var owned by remember{mutableStateOf(p.getStringSet("owned",emptySet())!!.toSet())};var fragment by remember{mutableStateOf("")};var fragments by remember{mutableStateOf(runCatching{val a=JSONArray(p.getString("fragments","[]") ?: "[]");List(a.length()){a.getString(it)}}.getOrDefault(emptyList()))};var message by remember{mutableStateOf("")}
 fun reward(n:Int){coins+=n;xp+=n;p.edit().putInt("coins",coins).putInt("xp",xp).apply()}
 Surface(Modifier.fillMaxSize(),color=night){Column(Modifier.fillMaxSize().systemBarsPadding()){
 if(!registered){Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
 if(stage==0){Box(Modifier.fillMaxWidth().height(420.dp).clip(RoundedCornerShape(24.dp))){Image(painterResource(R.drawable.lunar_scene),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,night.copy(alpha=.92f)),startY=400f)));Column(Modifier.align(Alignment.BottomCenter).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("Lunaris",fontSize=46.sp,color=gold,fontFamily=FontFamily.Serif);Text("Toda luz tem seu começo.",color=gold,textAlign=TextAlign.Center)}}}else{Text("Lunaris ☾",fontSize=32.sp,color=gold,fontFamily=FontFamily.Serif)}
 when(stage){0->{Text("Um espaço para cuidar de si e viver no seu ritmo.",textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth(),color=lunar);Button(onClick={stage=1},modifier=Modifier.fillMaxWidth().height(54.dp)){Text("Começar agora ✦")}}
 1->{OutlinedTextField(name,{name=it},label={Text("Como gostaria de ser chamado?")});OutlinedTextField(pronoun,{pronoun=it},label={Text("Pronome (opcional)")});OutlinedTextField(birth,{birth=it},label={Text("Nascimento: dd/mm/aaaa")});Text("A partir de 13 anos nesta versão.");Button(onClick={val valid=runCatching{val f=SimpleDateFormat("dd/MM/yyyy",Locale.US);f.isLenient=false;val d=f.parse(birth)!!;val c=java.util.Calendar.getInstance();c.add(java.util.Calendar.YEAR,-13);birth.matches(Regex("\\d{2}/\\d{2}/\\d{4}"))&&!d.after(c.time)}.getOrDefault(false);if(name.isBlank()||!valid)error="Informe um nome e uma data válida (13+)." else {error="";stage=2}}){Text("Continuar")};Text(error,color=gold)}
 else->{Text("Escolha seu refúgio gratuito");gardens.forEachIndexed{i,g->Tile{Art(gardenArt[i]);Row(verticalAlignment=Alignment.CenterVertically){RadioButton(garden==i,{garden=i});Text(g)}}};Button(onClick={p.edit().putString("name",name.trim()).putString("pronoun",pronoun).putInt("garden",garden).putBoolean("registered",true).apply();registered=true}){Text("Entrar no Lunaris")}}}
 }}else{
 Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("Lunaris ☾",fontSize=28.sp,color=gold,fontFamily=FontFamily.Serif);Text("✦ $coins Lúmens",color=gold)}
 Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 when(tab){0->{Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(20.dp))){Image(painterResource(gardenArt[garden]),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,night.copy(alpha=.9f)))));Text("Olá, $name ☾",fontSize=25.sp,color=gold,fontFamily=FontFamily.Serif,modifier=Modifier.align(Alignment.BottomStart).padding(16.dp))};Tile{Text("Como você está hoje?",fontSize=20.sp);Text("Responder é opcional.");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("Difícil","Triste","Neutro","Bem","Ótimo").forEachIndexed{i,m->Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if(mood==m) lunar.copy(alpha=.35f) else night).clickable{mood=m;p.edit().putString("mood_$day",m).apply()}.padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(listOf("☁","☂","☾","🌙","☀")[i],fontSize=24.sp,color=gold);Text(m,fontSize=10.sp)}}}};Tile{Text("Pequenos passos de hoje");(0..2).map{tasks[(offset+it)%tasks.size]}.forEach{t->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(t in completed,{checked->if(checked&&t !in completed){completed=completed+t;p.edit().putStringSet("tasks_$day",completed).apply();reward(10)}},enabled=t !in completed);Text(t)}};TextButton(onClick={offset=(offset+3)%tasks.size}){Text("Escolher outros passos")};Text("Você pode descansar quando quiser.")}}
 1->{Text("Descubra",fontSize=26.sp,fontFamily=FontFamily.Serif,color=gold);Art(R.drawable.lunar_scene,120);Tile{Text("Experiências criativas",color=gold,fontSize=20.sp);tasks.drop(3).forEachIndexed{i,t->Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(night).clickable{if(t !in completed){completed=completed+t;p.edit().putStringSet("tasks_$day",completed).apply();reward(15)}}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(listOf("✦","❀","☾","◇","♡","☆")[i],color=gold,fontSize=23.sp);Spacer(Modifier.width(12.dp));Text(t,Modifier.weight(1f),fontSize=14.sp);Text(if(t in completed)"✓" else "+15",color=lunar,fontSize=12.sp)}}};Tile{Text("Círculos e encontros");Text("Disponíveis quando a comunidade online estiver pronta.")};Tile{Text("Acolhimento");Text("O Lunaris não substitui atendimento profissional. No Brasil, CVV 188 para apoio emocional; em emergência, SAMU 192.")}}
 2->{Text("Meu Refúgio",fontSize=26.sp);Art(gardenArt[garden],340);Text(gardens[garden]);Text("✦ Sua jornada • $xp XP",color=gold);LinearProgressIndicator(progress={ (xp%100)/100f },modifier=Modifier.fillMaxWidth(),color=lunar,trackColor=panel);Text("Minhas decorações");owned.forEach{n->items.find{it.first==n}?.let{Tile{Art(it.third,110);Text(n)}}};Text("Tesouro Lunar",fontSize=22.sp);items.forEach{(n,price,art)->Tile{Art(art,110);Text(n);Button(enabled=n !in owned&&coins>=price,onClick={coins-=price;owned=owned+n;p.edit().putInt("coins",coins).putStringSet("owned",owned).apply()}){Text(if(n in owned)"Adquirido" else "$price Lúmens")}}};Tile{Text("Compra de Lúmens e Lunaris Plus");Text("Pagamentos reais indisponíveis nesta Alpha.")}}
 3->{Text("Entre Nós",fontSize=26.sp,fontFamily=FontFamily.Serif,color=gold);Art(R.drawable.lunar_scene,115);Tile{Text("Rascunhos privados de Fragmentos");Text("Nesta Alpha nada é publicado online.");OutlinedTextField(fragment,{fragment=it},label={Text("Seu fragmento")});Button(enabled=fragment.isNotBlank(),onClick={fragments=listOf(fragment.trim())+fragments;p.edit().putString("fragments",JSONArray(fragments).toString()).apply();fragment=""}){Text("Guardar rascunho")}};fragments.forEachIndexed{i,f->Tile{Text(f);TextButton(onClick={fragments=fragments.filterIndexed{j,_->j!=i};p.edit().putString("fragments",JSONArray(fragments).toString()).apply()}){Text("Excluir")}}}}
 else->{Text("Meu Espaço",fontSize=26.sp,fontFamily=FontFamily.Serif,color=gold);Art(gardenArt[garden],140);Tile{Text(name,fontSize=24.sp);Text(pronoun);Text("${fragments.size} rascunhos • $xp XP");Text("Laços e Inspirações: em desenvolvimento")};Tile{Text("Minha Jornada • Diário privado");OutlinedTextField(diary,{diary=it},label={Text("Como foi seu dia?")});Button(onClick={p.edit().putString("diary_$day",diary).apply();message="Diário salvo neste aparelho."}){Text("Salvar")};Text(message);TextButton(onClick={diary="";p.edit().remove("diary_$day").apply();message="Registro excluído."}){Text("Excluir registro de hoje")}};Tile{Text("Privacidade");Text("Dados locais, sem sincronização. Não há conta online nesta versão.")}}
 };Spacer(Modifier.height(12.dp))}
 NavigationBar(containerColor=panel){listOf("Hoje","Descubra","Refúgio","Entre Nós","Perfil").forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(listOf(Icons.Outlined.Home,Icons.Outlined.Explore,Icons.Outlined.NightsStay,Icons.Outlined.People,Icons.Outlined.Person)[i],contentDescription=null,tint=if(tab==i)gold else lunar)},label={Text(n,fontSize=10.sp)})}}
 }
 }}
}
