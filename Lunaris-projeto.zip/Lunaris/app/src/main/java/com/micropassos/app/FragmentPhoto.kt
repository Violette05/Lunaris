package com.micropassos.app

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import java.io.ByteArrayOutputStream

internal fun encodeFragmentPhoto(context: Context, uri: Uri): String {
 val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
 context.contentResolver.openInputStream(uri)!!.use{BitmapFactory.decodeStream(it,null,bounds)}
 require(bounds.outWidth>0 && bounds.outHeight>0)
 var sample=1
 while(maxOf(bounds.outWidth,bounds.outHeight)/sample>1600) sample*=2
 val original=context.contentResolver.openInputStream(uri)!!.use{BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply{inSampleSize=sample})} ?: error("Imagem inválida")
 val ratio=minOf(1f,960f/maxOf(original.width,original.height))
 var bitmap=Bitmap.createScaledBitmap(original,(original.width*ratio).toInt().coerceAtLeast(1),(original.height*ratio).toInt().coerceAtLeast(1),true)
 for(attempt in 0..7){
  val out=ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG,75-attempt.coerceAtMost(4)*10,out)
  val encoded=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP)
  if(encoded.length<=240000)return encoded
  if(attempt>=4)bitmap=Bitmap.createScaledBitmap(bitmap,(bitmap.width*.75f).toInt().coerceAtLeast(1),(bitmap.height*.75f).toInt().coerceAtLeast(1),true)
 }
 error("Imagem muito grande")
}

@Composable internal fun FragmentPhoto(encoded:String?) {
 val bitmap=remember(encoded){runCatching{if(encoded.isNullOrBlank() || encoded.length>240000)null else Base64.decode(encoded,Base64.DEFAULT).let{BitmapFactory.decodeByteArray(it,0,it.size)}}.getOrNull()}
 if(bitmap!=null)Image(bitmap.asImageBitmap(),"Fotografia do fragmento",Modifier.fillMaxWidth().heightIn(max=320.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Fit)
}
