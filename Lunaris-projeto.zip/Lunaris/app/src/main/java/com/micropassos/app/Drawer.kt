package com.micropassos.app
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable internal fun Drawer(title:String, subtitle:String="", content:@Composable ColumnScope.()->Unit){
 var expanded by rememberSaveable { mutableStateOf(false) }
 Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){
  Row(Modifier.fillMaxWidth().clickable{expanded=!expanded}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
   Column(Modifier.weight(1f)){Text(title,style=MaterialTheme.typography.titleMedium,color=MaterialTheme.colorScheme.primary);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.labelMedium)}
   Text(if(expanded) "⌃" else "⌄",style=MaterialTheme.typography.titleLarge)
  }
  if(expanded){HorizontalDivider();Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)}
 }
}
