package com.micropassos.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.DocumentSnapshot

@Composable internal fun SocialPanel(uid:String,name:String,bio:String,blocked:Set<String>) {
 val db=remember { FirebaseFirestore.getInstance() }
 val profiles=db.collection("publicProfiles")
 val mine=db.collection("users").document(uid)
 val links=db.collection("ties")
 var tab by remember { mutableStateOf(0) }
 var query by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("") }
 var people by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
 var incoming by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
 var outgoing by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
 var follows by remember { mutableStateOf<Set<String>>(emptySet()) }
 var circles by remember { mutableStateOf<Set<String>>(emptySet()) }
 DisposableEffect(uid) {
  val a=profiles.limit(100).addSnapshotListener{s,e->if(e==null)people=s?.documents.orEmpty() else status="Falha ao carregar perfis."}
  val b=links.whereEqualTo("to",uid).addSnapshotListener{s,e->if(e==null)incoming=s?.documents.orEmpty() else status="Falha ao carregar solicitações."}
  val c=links.whereEqualTo("from",uid).addSnapshotListener{s,e->if(e==null)outgoing=s?.documents.orEmpty() else status="Falha ao carregar laços."}
  val d=mine.collection("inspirations").addSnapshotListener{s,e->if(e==null)follows=s?.documents.orEmpty().map{it.id}.toSet()}
  val f=mine.collection("circles").addSnapshotListener{s,e->if(e==null)circles=s?.documents.orEmpty().map{it.id}.toSet()}
  onDispose{a.remove();b.remove();c.remove();d.remove();f.remove()}
 }
 var expanded by remember { mutableStateOf(false) }
 Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(8.dp)) {
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
  Text("Constelações",style=MaterialTheme.typography.titleMedium)
  TextButton(onClick={expanded=!expanded}){Text(if(expanded) "Fechar" else "Meu perfil") }
  }
  if(expanded){
  Button(enabled=name.isNotBlank(),onClick={profiles.document(uid).set(mapOf("name" to name.take(80),"bio" to bio.take(160))).addOnCompleteListener{status=if(it.isSuccessful)"Perfil publicado." else "Falha ao publicar perfil."}}){Text("Publicar / atualizar perfil")}
  TextButton(onClick={profiles.document(uid).delete().addOnCompleteListener{status=if(it.isSuccessful)"Perfil retirado da busca." else "Falha ao retirar perfil."}}){Text("Retirar perfil da busca")}
  }
  Row { listOf("Pessoas","Laços","Círculos").forEachIndexed{i,t->TextButton(onClick={tab=i}){Text(if(tab==i)"• $t" else t)}} }
  if(tab==0){
   OutlinedTextField(query,{query=it},placeholder={Text("Buscar pessoas")},singleLine=true,modifier=Modifier.fillMaxWidth())
   people.filter{it.id!=uid && it.id !in blocked && (it.getString("name") ?: "").contains(query,true)}.forEach{p->
    Text(p.getString("name") ?: "Lunaris",style=MaterialTheme.typography.titleMedium);Text(p.getString("bio") ?: "")
    val tie=(incoming+outgoing).firstOrNull{it.getString("from")==p.id || it.getString("to")==p.id}
    TextButton(onClick={val ref=mine.collection("inspirations").document(p.id);val task=if(p.id in follows)ref.delete() else ref.set(mapOf("uid" to p.id));task.addOnFailureListener{status="Falha ao atualizar inspiração."}}){Text(if(p.id in follows)"Deixar de acompanhar" else "Inspirar-se")}
    TextButton(enabled=tie==null,onClick={links.document(listOf(uid,p.id).sorted().joinToString("_")).set(mapOf("from" to uid,"to" to p.id,"state" to "pending")).addOnCompleteListener{status=if(it.isSuccessful)"Solicitação enviada." else "Falha ao solicitar laço."}}){Text(if(tie==null)"Criar Laço" else if(tie.getString("state")=="accepted")"Laço criado" else "Solicitação pendente")}
    HorizontalDivider()
   }
  } else if(tab==1){
   (incoming+outgoing).distinctBy{it.id}.filter{(if(it.getString("from")==uid)it.getString("to") else it.getString("from")) !in blocked}.forEach{t->
    val other=if(t.getString("from")==uid)t.getString("to") else t.getString("from")
    Text(people.firstOrNull{it.id==other}?.getString("name") ?: "Perfil indisponível")
    val accepted=t.getString("state")=="accepted"
    Text(if(accepted)"Laço ativo" else if(t.getString("to")==uid)"Solicitação recebida" else "Solicitação enviada")
    if(!accepted && t.getString("to")==uid) TextButton(onClick={t.reference.update("state","accepted").addOnFailureListener{status="Falha ao aceitar."}}){Text("Aceitar")}
    TextButton(onClick={t.reference.delete().addOnFailureListener{status="Falha ao remover."}}){Text(if(accepted)"Desfazer laço" else if(t.getString("to")==uid)"Recusar" else "Cancelar")}
   }
   Text("Inspirações: ${follows.size}")
  } else {
   listOf("arte" to "Arte e criatividade","natureza" to "Natureza","cotidiano" to "Pequenos passos","memorias" to "Memórias").forEach{(id,title)->
    Text(title);TextButton(onClick={val ref=mine.collection("circles").document(id);val task=if(id in circles)ref.delete() else ref.set(mapOf("id" to id));task.addOnFailureListener{status="Falha ao atualizar círculo."}}){Text(if(id in circles)"Sair do círculo" else "Participar")}
   }
   
  }
  if(status.isNotBlank()) Text(status)
 }}
}
