package com.micropassos.app

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

@Composable
internal fun GardenMagic(garden: Int, modifier: Modifier = Modifier) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var active by remember(lifecycle) { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, _ -> active = lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    var tick by remember(garden) { mutableIntStateOf(0) }
    val seeds = remember(garden) { val r = Random(720 + garden); List(22) { FloatArray(4) { r.nextFloat() } } }
    LaunchedEffect(active, garden) {
        if (active) while (true) { delay(50); tick = (tick + 1) % 72000 }
    }
    Canvas(modifier) {
        val t = tick * 0.05f
        val tint = when(garden) { 1 -> Color(0xFFFFE8A0); 2 -> Color(0xFFFFB8EC); else -> Color(0xFFE2C7FF) }
        seeds.forEachIndexed { i, p ->
            val x = (p[0] + .025f * sin(t * .45f + i)).coerceIn(.02f,.98f) * size.width
            val y = (p[1] - t * (.006f + p[2]*.008f)).let { ((it % 1f)+1f)%1f } * size.height
            val alpha = (.18f + .55f * (sin(t * (.65f+p[3]) + i)+1f)/2f)
            val center = Offset(x,y)
            val radius = (2f+p[2]*3f)*density
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha=alpha*.55f),Color.Transparent),center=center,radius=radius*3f),radius*3f,center)
            drawCircle(tint.copy(alpha=alpha),radius*.55f,center)
            if (i%5==0) {
                drawLine(tint.copy(alpha=alpha*.8f),center-Offset(radius*1.6f,0f),center+Offset(radius*1.6f,0f),strokeWidth=density)
                drawLine(tint.copy(alpha=alpha*.8f),center-Offset(0f,radius*1.6f),center+Offset(0f,radius*1.6f),strokeWidth=density)
            }
        }
    }
}
