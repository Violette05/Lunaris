package com.micropassos.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable internal fun OnlineGate(context: Context) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var guest by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var verified by remember { mutableStateOf(auth.currentUser?.isEmailVerified == true) }
    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser; verified = it.currentUser?.isEmailVerified == true }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    val current = user
    if (guest || (current != null && verified)) {
        key(if(guest) "guest" else current?.uid) {
            Lunaris(context, if(guest) null else current?.uid) {
                if(guest) {
                    Text("Modo local. Seus registros não são enviados à nuvem.")
                    TextButton(onClick={guest=false;message=""}) { Text("Entrar em uma conta") }
                } else if(current != null) {
                    val prefs = remember(current.uid) { context.getSharedPreferences("lunaris_account_${current.uid}", Context.MODE_PRIVATE) }
                    Text("Conta: ${current.email ?: ""}")
                    Text("Sincronização manual do nome, pronome e biografia.")
                    Button(enabled=!busy,onClick={busy=true;db.collection("users").document(current.uid).set(mapOf("name" to (prefs.getString("name", "") ?: ""),"pronoun" to (prefs.getString("pronoun", "") ?: ""),"bio" to (prefs.getString("bio", "") ?: ""))).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "Perfil enviado." else "Não foi possível enviar o perfil."}}){Text("Enviar perfil à nuvem")}
                    var refresh by remember { mutableStateOf(false) }
                    Button(enabled=!busy,onClick={busy=true;db.collection("users").document(current.uid).get().addOnCompleteListener{task->busy=false;val doc=if(task.isSuccessful) task.result else null;if(doc!=null && doc.exists()){prefs.edit().putString("name",doc.getString("name") ?: "").putString("pronoun",doc.getString("pronoun") ?: "").putString("bio",doc.getString("bio") ?: "").apply();refresh=true;message="Perfil recebido. Reabra o aplicativo para visualizar."}else message="Perfil indisponível."}}){Text("Baixar perfil da nuvem")}
                    Text(message)
                    TextButton(enabled=!busy,onClick={auth.signOut();password="";message=""}){Text("Sair da conta")}
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("Lunaris ☾",style=MaterialTheme.typography.headlineLarge)
            Text("Toda luz tem seu começo.")
            if(current!=null){
                Text("Confirme seu e-mail antes de continuar.")
                Button(enabled=!busy,onClick={busy=true;current.sendEmailVerification().addOnCompleteListener{busy=false;message=if(it.isSuccessful) "E-mail enviado. Confira sua caixa de entrada." else "Não foi possível enviar. Tente mais tarde."}}){Text("Enviar confirmação")}
                Button(enabled=!busy,onClick={busy=true;current.reload().addOnCompleteListener{busy=false;verified=it.isSuccessful && current.isEmailVerified;message=if(verified) "E-mail confirmado." else "Confirmação ainda pendente."}}){Text("Já confirmei")}
                TextButton(onClick={auth.signOut();message=""}){Text("Sair")}
            } else {
                OutlinedTextField(email,{email=it},label={Text("E-mail")},singleLine=true)
                OutlinedTextField(password,{password=it},label={Text("Senha")},singleLine=true,visualTransformation=PasswordVisualTransformation())
                Button(enabled=!busy && email.isNotBlank() && password.length>=6,onClick={busy=true;auth.signInWithEmailAndPassword(email.trim(),password).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "" else "Não foi possível entrar. Confira seus dados.";if(it.isSuccessful)password=""}}){Text("Entrar")}
                OutlinedButton(enabled=!busy && email.isNotBlank() && password.length>=6,onClick={busy=true;auth.createUserWithEmailAndPassword(email.trim(),password).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "Conta criada. Confirme seu e-mail." else "Não foi possível criar a conta.";if(it.isSuccessful)password=""}}){Text("Criar conta de teste")}
                TextButton(enabled=!busy && email.isNotBlank(),onClick={busy=true;auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener{busy=false;message="Se a conta existir, confira seu e-mail para recuperar a senha."}}){Text("Esqueci minha senha")}
                TextButton(enabled=!busy,onClick={guest=true;message=""}){Text("Continuar no modo local")}
            }
            if(busy) CircularProgressIndicator()
            Text(message)
            Text("Alpha privada: use somente contas de teste, sem dados sensíveis.")
        }
    }
}
