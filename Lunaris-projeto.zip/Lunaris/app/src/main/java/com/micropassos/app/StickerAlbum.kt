package com.micropassos.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable internal fun StickerAlbum(items:List<Triple<String,Int,Int>>, owned:Set<String>, close:()->Unit){
 var filter by remember { mutableStateOf("Todos") }
 var detail by remember { mutableStateOf<String?>(null) }
 fun rarity(name:String)=if(name=="Santuário de Selene") "S" else "C"
 val shown=items.filter{filter=="Todos" || rarity(it.first)==filter}
 val gold=Color(0xFFDFC28A)
 AlertDialog(onDismissRequest=close,title={Text("Grimório de colecionáveis",color=gold)},text={
 Column(Modifier.fillMaxWidth().heightIn(max=460.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text("${items.count{it.first in owned}} de ${items.size} descobertos")
 Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("Todos","C","R","E","S").forEach{r->FilterChip(selected=filter==r,onClick={filter=r;detail=null},label={Text(r)})}}
 if(shown.isEmpty()) Text("Novas relíquias chegarão futuramente.")
 shown.chunked(2).forEach{group->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
 group.forEach{item->val unlocked=item.first in owned;val supreme=rarity(item.first)=="S"
 OutlinedCard(Modifier.weight(1f).clickable{detail=item.first}){Column(Modifier.fillMaxWidth().padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally){
 Image(painterResource(item.third),if(unlocked)item.first else "Adesivo desconhecido",Modifier.size(80.dp),contentScale=ContentScale.Fit,colorFilter=if(unlocked)null else ColorFilter.tint(Color(0xFF171020)))
 Text(if(unlocked)item.first else "?",fontSize=12.sp,textAlign=TextAlign.Center)
 Text(if(supreme)"S · Supremo" else "C · Comum",fontSize=11.sp,color=if(supreme)gold else MaterialTheme.colorScheme.onSurfaceVariant)
 }} };repeat(2-group.size){Spacer(Modifier.weight(1f))}
 }}
 detail?.let{n->HorizontalDivider();Text(if(n in owned)n else "Relíquia desconhecida",color=gold);Text(if(n !in owned)"Ainda não descoberta." else if(rarity(n)=="S")"Um santuário celestial da Edição Fundadores." else if(items.indexOfFirst{it.first==n}>=3)"Relíquias do Luar · Edição Fundadores" else "Coleção inicial")}
 }
 },confirmButton={TextButton(onClick=close){Text("Fechar")}})
}
