package com.micropassos.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.*
import androidx.compose.ui.platform.LocalContext
import com.google.firebase.firestore.FirebaseFirestore
import kotlin.math.*

internal val auraNames=listOf("Sem moldura","Orvalho Lunar","Jardim de Lavanda","Constelação de Prata","Eclipse de Ametista","Coroa de Selene","Primeira Luz")
internal val coverNames=listOf("Jardim Lunar","Floresta Serena","Céu de Ametista")
@Composable internal fun AuraFrame(frame:Int, size:Int=48, content:@Composable ()->Unit){
 val transition=if(frame==5) rememberInfiniteTransition(label="aura") else null
 val phase=if(transition!=null) transition.animateFloat(0f,360f,infiniteRepeatable(tween(9000,easing=LinearEasing)),label="orbit").value else 0f
 Box(Modifier.size(size.dp),contentAlignment=Alignment.Center){
  content()
  if(frame in 1..6) Canvas(Modifier.fillMaxSize()){
   val colors=listOf(Color.Transparent,Color(0xFFB7DFD9),Color(0xFFC9A4EF),Color(0xFFDDE7FA),Color(0xFFAB72E9),Color(0xFFFFD68A),Color(0xFFDFC28A))
   val c=colors[frame];val r=this.size.minDimension/2-2.dp.toPx()
   drawCircle(c,r,style=Stroke(2.dp.toPx()))
   if(frame>=3) drawCircle(c.copy(alpha=.5f),r-3.dp.toPx(),style=Stroke(1.dp.toPx()))
   val n=if(frame==5) 6 else if(frame>=2) 4 else 0
   repeat(n){i->val a=(i*360f/n+phase)*PI/180;val p=center+Offset((cos(a)*r).toFloat(),(sin(a)*r).toFloat());drawCircle(c,2.5.dp.toPx(),p);if(frame==5)drawCircle(c.copy(alpha=.22f),5.dp.toPx(),p)}
  }
 }
}
@Composable internal fun AuraCover(cover:Int){
 val colors=when(cover){1->listOf(Color(0xFF193B35),Color(0xFF75977D));2->listOf(Color(0xFF241238),Color(0xFF9363B3));else->listOf(Color(0xFF211831),Color(0xFF65507F))}
 Box(Modifier.fillMaxWidth().height(100.dp).background(Brush.horizontalGradient(colors)),contentAlignment=Alignment.Center){Text("✧     ☾     ✧",color=Color(0xFFDFC28A),style=MaterialTheme.typography.headlineLarge)}
}
@Composable internal fun AuraEditor(uid:String?, frame:Int, cover:Int, onFrame:(Int)->Unit,onCover:(Int)->Unit){
 var draft by remember(frame){mutableIntStateOf(frame)};var draftCover by remember(cover){mutableIntStateOf(cover)};var status by remember{mutableStateOf("")}
 Drawer("Aura Celestial","Molduras e capas"){
  AuraCover(draftCover)
  AuraFrame(draft,76){Box(Modifier.size(64.dp).background(MaterialTheme.colorScheme.secondaryContainer,CircleShape),contentAlignment=Alignment.Center){Text("☾")}}
  Text("Molduras • catálogo de teste gratuito")
  auraNames.forEachIndexed{i,n->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(draft==i,{draft=i});Text(n)}}
  Text("Capas")
  coverNames.forEachIndexed{i,n->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(draftCover==i,{draftCover=i});Text(n)}}
  Button(onClick={onFrame(draft);onCover(draftCover);status="Personalização salva neste aparelho."}){Text("Equipar")}
  if(uid!=null){TextButton(onClick={FirebaseFirestore.getInstance().collection("lunarAuras").document(uid).set(mapOf("frame" to frame,"cover" to cover)).addOnCompleteListener{status=if(it.isSuccessful)"Aura publicada." else "Falha ao publicar aura."}}){Text("Publicar aura equipada")};TextButton(onClick={FirebaseFirestore.getInstance().collection("lunarAuras").document(uid).delete().addOnCompleteListener{status=if(it.isSuccessful)"Aura retirada." else "Falha ao retirar aura."}}){Text("Retirar aura pública")}}
  if(status.isNotBlank())Text(status)
 }
}
